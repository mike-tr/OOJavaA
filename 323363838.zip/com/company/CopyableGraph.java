package com.company;

import ex0.graph;

public interface CopyableGraph extends graph {
    // totally unnecessary but i want a way to get a deepCopy easily from different types of graph's
    // i assume there will be different types of graph's.
    CopyableGraph getDeepCopy();
}
